import arcpy
import os
from datetime import datetime

def migrate_file_to_personal_gdb(input_file_gdb, output_folder):
    """Migrate data from a file geodatabase to a personal geodatabase and generate a report."""
    try:
        # Set the workspace to the input file geodatabase
        arcpy.env.workspace = input_file_gdb

        # Create a new personal geodatabase in the output folder
        output_personal_gdb_name = os.path.splitext(os.path.basename(input_file_gdb))[0] + ".mdb"
        output_personal_gdb = os.path.join(output_folder, output_personal_gdb_name)
        
        print("Output Personal GDB Name: {}".format(output_personal_gdb_name))
        print("Output Personal GDB Path: {}".format(output_personal_gdb))
        
        if not arcpy.Exists(output_personal_gdb):
            arcpy.CreatePersonalGDB_management(output_folder, output_personal_gdb_name)
            print("Created Personal Geodatabase: {}".format(output_personal_gdb))
        else:
            print("Personal Geodatabase already exists: {}".format(output_personal_gdb))

        # Initialize report content
        report_content = []
        report_content.append("<html><body><h2>Migration Report</h2>")
        report_content.append("<p>Date: {}</p>".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        report_content.append("<p>Source File Geodatabase: {}</p>".format(input_file_gdb))
        report_content.append("<p>Destination Personal Geodatabase: {}</p>".format(output_personal_gdb))
        report_content.append("<p>Developed by: AM Manamperi, Map Technological Officer, GIS Branch, Survey Department of Sri Lanka 2024 | Email: amilamanamperi@outlook.com</p>")
        report_content.append("<h3>Details:</h3>")

        # Get a list of all feature datasets in the file geodatabase
        feature_datasets = arcpy.ListDatasets(feature_type='feature') or []
        
        # Get a list of all feature classes and tables not in a feature dataset
        feature_classes = arcpy.ListFeatureClasses() or []
        tables = arcpy.ListTables() or []

        # Copy feature datasets and their feature classes
        for fds in feature_datasets:
            output_fds = os.path.join(output_personal_gdb, fds)
            report_content.append("<h4>Feature Dataset: {}</h4>".format(fds))
            arcpy.CreateFeatureDataset_management(output_personal_gdb, fds, arcpy.Describe(fds).spatialReference)
            
            # Set the workspace to the feature dataset to get the feature classes inside it
            arcpy.env.workspace = os.path.join(input_file_gdb, fds)
            fds_feature_classes = arcpy.ListFeatureClasses() or []
            for fc in fds_feature_classes:
                output_fc = os.path.join(output_fds, fc)
                try:
                    arcpy.CopyFeatures_management(fc, output_fc)
                    report_content.append("<p>  Feature Class: {} - Successfully migrated</p>".format(fc))
                except Exception as e:
                    report_content.append("<p>  Feature Class: {} - Failed to migrate: {}</p>".format(fc, str(e)))

        # Reset the workspace to the file geodatabase root
        arcpy.env.workspace = input_file_gdb

        # Copy feature classes not in any feature dataset
        for fc in feature_classes:
            output_fc = os.path.join(output_personal_gdb, fc)
            try:
                arcpy.CopyFeatures_management(fc, output_fc)
                report_content.append("<p>Feature Class: {} - Successfully migrated</p>".format(fc))
            except Exception as e:
                report_content.append("<p>Feature Class: {} - Failed to migrate: {}</p>".format(fc, str(e)))

        # Copy tables to the new personal geodatabase
        for table in tables:
            output_table = os.path.join(output_personal_gdb, table)
            try:
                arcpy.CopyRows_management(table, output_table)
                report_content.append("<p>Table: {} - Successfully migrated</p>".format(table))
            except Exception as e:
                report_content.append("<p>Table: {} - Failed to migrate: {}</p>".format(table, str(e)))

        print("Migration completed successfully!")
        print("Personal Geodatabase created at: {}".format(output_personal_gdb))

        # Save the report
        report_directory = r"C:\NSDI_DB\Reports"
        if not os.path.exists(report_directory):
            os.makedirs(report_directory)
        
        report_filename = os.path.join(report_directory, "Migration_Report_{}.html".format(datetime.now().strftime("%Y%m%d_%H%M%S")))
        with open(report_filename, 'w') as report_file:
            report_file.writelines(report_content)
        report_content.append("</body></html>")
        
        print("Report saved to: {}".format(report_filename))

    except arcpy.ExecuteError:
        print("ArcPy error: {}".format(arcpy.GetMessages(2)))
    except Exception as e:
        print("An error occurred: {}".format(str(e)))
    finally:
        # Reset the workspace to avoid conflicts
        arcpy.env.workspace = None

# Main Script
if __name__ == "__main__":
    print("Starting File Geodatabase to Personal Geodatabase migration...")

    # The input file geodatabase and output folder are passed as script arguments
    input_file_gdb = arcpy.GetParameterAsText(0)  # Assuming this is parameter 0
    output_folder = arcpy.GetParameterAsText(1)   # Assuming this is parameter 1

    # Run the migration function
    migrate_file_to_personal_gdb(input_file_gdb, output_folder)

# Add a message to show after the tool has run
arcpy.AddMessage("Developed by: AM Manamperi, Map Technological Officer, GIS Branch, Survey Department of Sri Lanka 2024 | Email: amilamanamperi@outlook.com")

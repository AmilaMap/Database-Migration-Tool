import arcpy
import os
from datetime import datetime

def migrate_personal_to_file_gdb(input_personal_gdb, output_folder):
    """Migrate data from a personal geodatabase to a file geodatabase and generate a report."""
    try:
        # Set the workspace to the input personal geodatabase
        arcpy.env.workspace = input_personal_gdb

        # Create a new file geodatabase in the output folder
        output_gdb_name = os.path.splitext(os.path.basename(input_personal_gdb))[0] + ".gdb"
        output_file_gdb = os.path.join(output_folder, output_gdb_name)
        
        print("Output GDB Name: {}".format(output_gdb_name))
        print("Output File GDB Path: {}".format(output_file_gdb))
        
        if not arcpy.Exists(output_file_gdb):
            arcpy.CreateFileGDB_management(output_folder, os.path.splitext(output_gdb_name)[0])
            print("Created File Geodatabase: {}".format(output_file_gdb))
        else:
            print("File Geodatabase already exists: {}".format(output_file_gdb))

        # Initialize report content
        report_content = []
        report_content.append("<html><body><h2>Migration Report</h2>")
        report_content.append("<p>Date: {}</p>".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        report_content.append("<p>Source Personal Geodatabase: {}</p>".format(input_personal_gdb))
        report_content.append("<p>Destination File Geodatabase: {}</p>".format(output_file_gdb))
        report_content.append("<p>Developed by: AM Manamperi, Map Technological Officer, GIS Branch, Survey Department of Sri Lanka 2024 | Email: amilamanamperi@outlook.com</p>")
        report_content.append("<h3>Details:</h3>")

        # Get a list of all feature datasets in the personal geodatabase
        feature_datasets = arcpy.ListDatasets(feature_type='feature') or []
        
        # Get a list of all feature classes and tables not in a feature dataset
        feature_classes = arcpy.ListFeatureClasses() or []
        tables = arcpy.ListTables() or []

        # Copy feature datasets and their feature classes
        for fds in feature_datasets:
            output_fds = os.path.join(output_file_gdb, fds)
            report_content.append("<h4>Feature Dataset: {}</h4>".format(fds))
            arcpy.CreateFeatureDataset_management(output_file_gdb, fds, arcpy.Describe(fds).spatialReference)
            
            # Set the workspace to the feature dataset to get the feature classes inside it
            arcpy.env.workspace = os.path.join(input_personal_gdb, fds)
            fds_feature_classes = arcpy.ListFeatureClasses() or []
            for fc in fds_feature_classes:
                output_fc = os.path.join(output_fds, fc)
                try:
                    arcpy.CopyFeatures_management(fc, output_fc)
                    report_content.append("<p>  Feature Class: {} - Successfully migrated</p>".format(fc))
                except Exception as e:
                    report_content.append("<p>  Feature Class: {} - Failed to migrate: {}</p>".format(fc, str(e)))

        # Reset the workspace to the personal geodatabase root
        arcpy.env.workspace = input_personal_gdb

        # Copy feature classes not in any feature dataset
        for fc in feature_classes:
            output_fc = os.path.join(output_file_gdb, fc)
            try:
                arcpy.CopyFeatures_management(fc, output_fc)
                report_content.append("<p>Feature Class: {} - Successfully migrated</p>".format(fc))
            except Exception as e:
                report_content.append("<p>Feature Class: {} - Failed to migrate: {}</p>".format(fc, str(e)))

        # Copy tables to the new file geodatabase
        for table in tables:
            output_table = os.path.join(output_file_gdb, table)
            try:
                arcpy.CopyRows_management(table, output_table)
                report_content.append("<p>Table: {} - Successfully migrated</p>".format(table))
            except Exception as e:
                report_content.append("<p>Table: {} - Failed to migrate: {}</p>".format(table, str(e)))

        print("Migration completed successfully!")
        print("File Geodatabase created at: {}".format(output_file_gdb))

        # Save the report
        report_directory = r"C:\NSDI_DB\Reports"
        if not os.path.exists(report_directory):
            os.makedirs(report_directory)
        
        report_filename = os.path.join(report_directory, "Migration_Report_{}.html".format(datetime.now().strftime("%Y%m%d_%H%M%S")))
        with open(report_filename, 'w') as report_file:
            report_file.writelines(report_content)
        report_content.append("</body></html>")
        
        print("Report saved to: {}".format(report_filename))

    except arcpy.ExecuteError:
        print("ArcPy error: {}".format(arcpy.GetMessages(2)))
    except Exception as e:
        print("An error occurred: {}".format(str(e)))
    finally:
        # Reset the workspace to avoid conflicts
        arcpy.env.workspace = None

# Main Script
if __name__ == "__main__":
    print("Starting Personal Geodatabase to File Geodatabase migration...")

    # The input personal geodatabase and output folder are passed as script arguments
    input_personal_gdb = arcpy.GetParameterAsText(0)  # Assuming this is parameter 0
    output_folder = arcpy.GetParameterAsText(1)       # Assuming this is parameter 1

    # Run the migration function
    migrate_personal_to_file_gdb(input_personal_gdb, output_folder)

# Add a message to show after the tool has run
arcpy.AddMessage("Developed by: AM Manamperi, Map Technological Officer, GIS Branch, Survey Department of Sri Lanka 2024 | Email: amilamanamperi@outlook.com")
